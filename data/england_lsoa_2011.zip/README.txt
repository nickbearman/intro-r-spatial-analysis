Files:
england_lsoa_2011.shx
england_lsoa_2011.prj
england_lsoa_2011.dbf
england_lsoa_2011.shp

Areas:
Liverpool

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.